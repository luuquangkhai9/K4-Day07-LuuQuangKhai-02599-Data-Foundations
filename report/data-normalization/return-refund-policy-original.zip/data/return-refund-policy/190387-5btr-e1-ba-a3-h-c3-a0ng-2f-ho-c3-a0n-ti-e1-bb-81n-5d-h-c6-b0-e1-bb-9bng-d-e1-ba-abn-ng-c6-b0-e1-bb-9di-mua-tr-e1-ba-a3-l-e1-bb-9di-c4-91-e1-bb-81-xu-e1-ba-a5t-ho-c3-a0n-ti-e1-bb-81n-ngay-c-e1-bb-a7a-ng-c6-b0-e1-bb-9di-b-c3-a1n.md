---
doc_id: "190387-5btr-e1-ba-a3-h-c3-a0ng-2f-ho-c3-a0n-ti-e1-bb-81n-5d-h-c6-b0-e1-bb-9bng-d-e1-ba-abn-ng-c6-b0-e1-bb-9di-mua-tr-e1-ba-a3-l-e1-bb-9di-c4-91-e1-bb-81-xu-e1-ba-a5t-ho-c3-a0n-ti-e1-bb-81n-ngay-c-e1-bb-a7a-ng-c6-b0-e1-bb-9di-b-c3-a1n"
title: "[Trả hàng/ Hoàn tiền] Hướng dẫn Người mua trả lời đề xuất Hoàn Tiền Ngay của Người bán | Shopee Trung tâm trợ giúp"
source_url: "https://help.shopee.vn/portal/4/article/190387-%5BTr%E1%BA%A3-h%C3%A0ng%2F-Ho%C3%A0n-ti%E1%BB%81n%5D-H%C6%B0%E1%BB%9Bng-d%E1%BA%ABn-Ng%C6%B0%E1%BB%9Di-mua-tr%E1%BA%A3-l%E1%BB%9Di-%C4%91%E1%BB%81-xu%E1%BA%A5t-Ho%C3%A0n-Ti%E1%BB%81n-Ngay-c%E1%BB%A7a-Ng%C6%B0%E1%BB%9Di-b%C3%A1n?previousPage=secondary%20category"
retrieved_at: "2026-09-20"
document_version: "not-stated"
---

# [Trả hàng/ Hoàn tiền] Hướng dẫn Người mua trả lời đề xuất Hoàn Tiền Ngay của Người bán | Shopee Trung tâm trợ giúp

[Trả hàng/ Hoàn tiền] Hướng dẫn Người mua trả lời đề xuất Hoàn Tiền Ngay của Người bán | Shopee Trung tâm trợ giúp

Xin chào, Shopee có thể giúp gì cho bạn?

[Trả hàng/ Hoàn tiền] Hướng dẫn Người mua trả lời đề xuất Hoàn Tiền Ngay của Người bán

Trong một số trường hợp, khi bạn tạo yêu cầu Trả hàng/Hoàn tiền (THHT), Người bán có thể gửi cho bạn một đề xuất Hoàn tiền ngay (một phần hoặc toàn bộ giá trị đơn hàng).

Điều này giúp rút ngắn thời gian xử lý và mang lại trải nghiệm nhanh chóng hơn cho bạn. Dưới đây là các bước để phản hồi đề xuất của Người bán:

Bước 1: Vào mục Tôi > chọn Trả hàng/Hoàn tiền

> Tại đơn hàng cần phản hồi, chọn Chi tiết Trả hàng Hoàn tiền

Bước 2: Kiểm tra kỹ số tiền hoàn mà Người bán đề xuất

Trường hợp 1: Bạn đồng ý với số tiền Người bán đề xuất

Chọn Trao đổi thêm

Nhấn Đồng ý

> Bạn sẽ nhận được tiền hoàn ngay mà không cần trả hàng

 

Trường hợp 2:  Bạn KHÔNG đồng ý với số tiền Người bán đề xuất

Bạn có thể chọn 1 trong 2 cách sau:

Nhấn Trao đổi thêm để Chat với Người bán nếu cần thương lượng thêm

HOẶC Nhấn Tôi muốn trả hàng để tiếp tục quy trình trả sản phẩm và nhận toàn bộ số tiền theo yêu cầu THHT ban đầu

Bạn có thể tìm hiểu thêm các bài viết khác về Trả hàng/Hoàn tiền tại đây.

Bạn có hài lòng với bài viết này?

Hài lòng

Không hài lòng
