---
doc_id: "189476-5btr-e1-ba-a3-h-c3-a0ng-2f-ho-c3-a0n-ti-e1-bb-81n-5d-c-c3-a1ch-theo-d-c3-b5i-t-c3-acnh-tr-e1-ba-a1ng-v-e1-ba-adn-chuy-e1-bb-83n-h-c3-a0ng-ho-c3-a0n-tr-e1-ba-a3"
title: "[Trả hàng/ Hoàn tiền] Cách theo dõi tình trạng vận chuyển hàng hoàn trả | Shopee Trung tâm trợ giúp"
source_url: "https://help.shopee.vn/portal/4/article/189476-%5BTr%E1%BA%A3-h%C3%A0ng%2F-Ho%C3%A0n-ti%E1%BB%81n%5D-C%C3%A1ch-theo-d%C3%B5i-t%C3%ACnh-tr%E1%BA%A1ng-v%E1%BA%ADn-chuy%E1%BB%83n-h%C3%A0ng-ho%C3%A0n-tr%E1%BA%A3?previousPage=secondary%20category"
retrieved_at: "2026-09-20"
document_version: "not-stated"
---

# [Trả hàng/ Hoàn tiền] Cách theo dõi tình trạng vận chuyển hàng hoàn trả | Shopee Trung tâm trợ giúp

[Trả hàng/ Hoàn tiền] Cách theo dõi tình trạng vận chuyển hàng hoàn trả | Shopee Trung tâm trợ giúp

Xin chào, Shopee có thể giúp gì cho bạn?

[Trả hàng/ Hoàn tiền] Cách theo dõi tình trạng vận chuyển hàng hoàn trả

1. Nếu bạn chọn trả hàng bằng hình thức Đơn vị vận chuyển đến lấy hàng hoặc Trả hàng tại bưu cục

 

Bạn có thể kiểm tra tình trạng vận chuyển đơn hoàn trả ngay trên ứng dụng Shopee bằng cách vào mục: Tôi > Trả hàng/Hoàn tiền > Tại đơn hàng cần kiểm tra, bấm Xem chi tiết > bấm Chi tiết để xem toàn bộ hành trình và thời gian giao hàng dự kiến

 

 

2. Nếu bạn chọn trả hàng bằng hình thức Tự sắp xếp:

Bạn có thể kiểm tra tình trạng vận chuyển đơn hoàn trả bằng mã vận đơn tại trang web của đơn vị vận chuyển mà bạn đã gửi hàng.

Danh sách trang tra cứu và thông tin liên hệ của một vài đơn vị vận chuyển bạn có thể tham khảo tại đây.

1

1

1

Bạn có hài lòng với bài viết này?

Hài lòng

Không hài lòng
