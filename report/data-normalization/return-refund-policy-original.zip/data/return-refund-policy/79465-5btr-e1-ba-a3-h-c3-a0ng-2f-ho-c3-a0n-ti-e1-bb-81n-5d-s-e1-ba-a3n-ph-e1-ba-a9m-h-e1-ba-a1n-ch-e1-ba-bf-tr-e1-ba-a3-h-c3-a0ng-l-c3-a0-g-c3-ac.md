---
doc_id: "79465-5btr-e1-ba-a3-h-c3-a0ng-2f-ho-c3-a0n-ti-e1-bb-81n-5d-s-e1-ba-a3n-ph-e1-ba-a9m-h-e1-ba-a1n-ch-e1-ba-bf-tr-e1-ba-a3-h-c3-a0ng-l-c3-a0-g-c3-ac"
title: "[Trả hàng/ Hoàn tiền] Sản phẩm hạn chế trả hàng là gì? | Shopee Trung tâm trợ giúp"
source_url: "https://help.shopee.vn/portal/4/article/79465-%5BTr%E1%BA%A3-h%C3%A0ng%2F-Ho%C3%A0n-ti%E1%BB%81n%5D-S%E1%BA%A3n-ph%E1%BA%A9m-h%E1%BA%A1n-ch%E1%BA%BF-tr%E1%BA%A3-h%C3%A0ng-l%C3%A0-g%C3%AC?previousPage=secondary%20category"
retrieved_at: "2026-09-20"
document_version: "not-stated"
---

# [Trả hàng/ Hoàn tiền] Sản phẩm hạn chế trả hàng là gì? | Shopee Trung tâm trợ giúp

[Trả hàng/ Hoàn tiền] Sản phẩm hạn chế trả hàng là gì? | Shopee Trung tâm trợ giúp

Xin chào, Shopee có thể giúp gì cho bạn?

[Trả hàng/ Hoàn tiền] Sản phẩm hạn chế trả hàng là gì?

Sản phẩm hạn chế trả hàng là những sản phẩm có tính đặc thù cao, dễ hư hỏng hoặc cần điều kiện bảo quản nghiêm ngặt. Đối với nhóm sản phẩm này, Shopee không áp dụng lý do trả hàng “Đổi ý (Sản phẩm còn nguyên tem, nhãn mác, bao bì)”.

 

Sản phẩm hạn chế trả hàng thuộc các nhóm sản phẩm dưới đây:

 

Danh mục sản phẩm hạn chế

Bao gồm Các Sản Phẩm

Sức khỏe, Vệ sinh & Đồ cá nhân

· Thiết bị Y tế cá nhân

· Găng tay, khẩu trang y tế

· Trang phục và dụng cụ Mẹ & Bé

· Trang phục lót, Đồ bơi & Vớ/Tất
· Thuốc không kê đơn

Thực phẩm & Hàng mau hỏng

· Thực phẩm tươi sống, Đông lạnh, Chế biến & Bánh tươi.

· Cây cảnh, hoa tươi và các sản phẩm mau hỏng

Hàng đặc thù trong vận chuyển

· Phương tiện giao thông & Dầu nhớt động cơ

· Trang sức vàng, thẻ vàng

Sản phẩm số và dịch vụ

· Thẻ sim & Thẻ điện thoại

· Vouchers dịch vụ & Thẻ quà tặng

Khác

· Một số sản phẩm khác theo từng thời điểm cụ thể dựa trên đánh giá từ Shopee về tính hợp lệ, minh bạch và hiệu quả.

·  Các thông tin sẽ được ghi chú rõ ràng tại trang chi tiết/ hoặc hình ảnh sản phẩm hoặc các nội dung đăng tải công khai khác…

 

Lưu ý: Danh sách này có thể thay đổi tùy từng thời điểm theo quyết định của Shopee.

Bạn có hài lòng với bài viết này?

Hài lòng

Không hài lòng
