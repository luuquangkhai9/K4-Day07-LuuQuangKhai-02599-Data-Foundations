---
doc_id: "189473-5btr-e1-ba-a3-h-c3-a0ng-2f-ho-c3-a0n-ti-e1-bb-81n-5d-th-e1-bb-9di-gian-nh-e1-ba-adn-ti-e1-bb-81n-ho-c3-a0n-v-c3-a0-c-c3-a1ch-ki-e1-bb-83m-tra-ti-e1-bb-81n-ho-c3-a0n"
title: "[Trả hàng/ Hoàn tiền] Thời gian nhận tiền hoàn và cách kiểm tra tiền hoàn | Shopee Trung tâm trợ giúp"
source_url: "https://help.shopee.vn/portal/4/article/189473-%5BTr%E1%BA%A3-h%C3%A0ng%2F-Ho%C3%A0n-ti%E1%BB%81n%5D-Th%E1%BB%9Di-gian-nh%E1%BA%ADn-ti%E1%BB%81n-ho%C3%A0n-v%C3%A0-c%C3%A1ch-ki%E1%BB%83m-tra-ti%E1%BB%81n-ho%C3%A0n?previousPage=secondary%20category"
retrieved_at: "2026-09-20"
document_version: "not-stated"
---

# [Trả hàng/ Hoàn tiền] Thời gian nhận tiền hoàn và cách kiểm tra tiền hoàn | Shopee Trung tâm trợ giúp

[Trả hàng/ Hoàn tiền] Thời gian nhận tiền hoàn và cách kiểm tra tiền hoàn | Shopee Trung tâm trợ giúp

Xin chào, Shopee có thể giúp gì cho bạn?

[Trả hàng/ Hoàn tiền] Thời gian nhận tiền hoàn và cách kiểm tra tiền hoàn

Sau khi gửi trả hàng, bạn sẽ nhận được thông báo xác nhận hoàn tiền qua mục Thông báo > Cập nhật đơn hàng trên ứng dụng Shopee, sau đó tiền sẽ được hoàn theo các phương thức thanh toán sau: 

 

 

Phương thức thanh toán

Tiền hoàn trả được gửi qua

Thời gian nhận được tiền hoàn sau khi Shopee chấp nhận hoàn tiền

Thanh toán khi nhận hàng/ Thanh toán QR

Ví ShopeePay 

24 giờ (với điều kiện Ví 

Shopee Pay vẫn hoạt động

bình thường)

Tài khoản Ngân hàng mặc định được liên kết với tài khoản Shopee.

2 ngày làm việc (tùy ngân hàng)

Ứng dụng Ngân hàng

Tài khoản Ngân hàng ban đầu

7 ngày làm việc

Ví ShopeePay

Ví ShopeePay

24 giờ (với điều kiện Ví 

Shopee Pay vẫn hoạt động

bình thường)

Thẻ nội địa Napas

Thẻ nội địa Napas

2 - 5 ngày làm việc (tùy ngân hàng)

Thẻ tín dụng/ghi nợ

Thẻ tín dụng/ghi nợ

7 - 14 ngày làm việc (tùy theo ngân hàng)

Apple Pay

Thẻ tín dụng/ghi nợ liên kết với tài khoản Apple Pay

7 - 14 ngày làm việc (tùy theo ngân hàng)

Google Pay

Thẻ tín dụng/ghi nợ liên kết với tài khoản Google Pay (Google Wallet)

7 - 14 ngày làm việc (tùy theo ngân hàng)

SPayLater

Mục Giao dịch trong SPayLater

 

*Lưu ý: 

Nếu bạn gửi yêu cầu THHT sau khi đơn cập nhật trạng thái “Hoàn thành” - giao dịch trả góp đã được ghi nhận với ngân hàng:
-> Bạn vẫn cần trả góp cho đơn hàng này dù đã được chấp nhận Trả hàng/Hoàn tiền. Shopee sẽ hoàn trước 100% tiền hàng (tiền hoàn bao gồm số tiền gốc và không bao gồm phí chuyển đổi trả góp) vào tài khoản SPayLater của bạn, số tiền này sẽ được cấn trừ vào hóa đơn trả góp gần nhất. 

24 giờ

Bảng 1: Phương thức hoàn tiền và thời gian hoàn tiền theo các phương thức thanh toán trên Shopee

 

⚠️ Lưu ý:

Trong quá trình xử lý nếu Người bán có khiếu nại, Shopee sẽ xem xét & thông báo kết quả cuối cùng đến bạn tại mục Thông báo > Cập nhật đơn hàng trong vòng 3-5 ngày làm việc kể từ lúc tiếp nhận khiếu nại từ Người bán

Đối với hình thức trả hàng “Tự sắp xếp”, Phí trả hàng sẽ được hoàn lại cho bạn theo Chính sách hỗ trợ phí trả hàng

Đối với đơn hàng thanh toán bằng Thẻ Tín dụng/Ghi nợ, Shopee chỉ hỗ trợ hoàn tiền về đúng tài khoản Tín dụng/Ghi nợ đã sử dụng khi thanh toán đơn hàng.

Đối với hình thức hoàn tiền về Tài khoản Ngân hàng, bạn cần đảm bảo nhập đúng thông tin chủ tài khoản, số tài khoản và tên ngân hàng để được xử lý hoàn tiền thành công trong 24h.

Đối với các hình thức hoàn tiền về Ví Shopee Pay, tại thời điểm xử lý hoàn tiền, ví cần ở trạng thái bình thường và còn liên kết với tài khoản Shopee để việc hoàn tiền thành công trong 24h. 

Đối với các đơn hàng thanh toán bằng hình thức Thanh toán khi nhận hàng hoặc Thanh toán QR/Ứng dụng ngân hàng, kênh hoàn tiền sẽ tùy theo phương thức hoàn tiền khi bạn gửi yêu cầu Trả hàng Hoàn tiền. Trong trường hợp thông tin tài khoản Ngân hàng không chính xác/Ví ShopeePay của bạn không ở trạng thái hoạt động bình thường ở thời điểm xử lý hoàn tiền, bạn cần cập nhật lại thông tin tài khoản Ngân hàng/Ví ShopeePay của bạn để được nhận tiền hoàn.

Đối với các đơn hàng thanh toán bằng SPayLater kết hợp với các phương thức thanh toán khác:

Số tiền đã thanh toán bằng SPayLater: hoàn về Số dư khả dụng SPayLater trong 24 giờ hoặc Hóa đơn SPayLater trong 3 - 5 ngày làm việc tiếp theo (chi tiết xem tại Bảng bên trên)

Số tiền thanh toán bằng phương thức thanh toán khác: hoàn về Ví ShopeePay (nếu trước đó bạn chon thanh toán bằng Ví ShopeePay) hoặc Số dư TK Shopee (nếu trước đó bạn chọn thanh toán bằng Thanh toán QR/Ứng dụng ngân hàng) trong 24 giờ tiếp theo.

Bạn có hài lòng với bài viết này?

Hài lòng

Không hài lòng
