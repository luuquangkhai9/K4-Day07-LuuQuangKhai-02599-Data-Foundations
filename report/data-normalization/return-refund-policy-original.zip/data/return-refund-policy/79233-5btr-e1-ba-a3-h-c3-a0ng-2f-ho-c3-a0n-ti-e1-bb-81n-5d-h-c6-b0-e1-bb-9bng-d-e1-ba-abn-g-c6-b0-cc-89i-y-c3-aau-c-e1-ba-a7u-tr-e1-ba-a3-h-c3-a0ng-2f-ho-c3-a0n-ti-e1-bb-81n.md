---
doc_id: "79233-5btr-e1-ba-a3-h-c3-a0ng-2f-ho-c3-a0n-ti-e1-bb-81n-5d-h-c6-b0-e1-bb-9bng-d-e1-ba-abn-g-c6-b0-cc-89i-y-c3-aau-c-e1-ba-a7u-tr-e1-ba-a3-h-c3-a0ng-2f-ho-c3-a0n-ti-e1-bb-81n"
title: "[Trả hàng/ Hoàn tiền] Hướng dẫn gửi yêu cầu Trả hàng/ Hoàn tiền | Shopee Trung tâm trợ giúp"
source_url: "https://help.shopee.vn/portal/4/article/79233-%5BTr%E1%BA%A3-h%C3%A0ng%2F-Ho%C3%A0n-ti%E1%BB%81n%5D-H%C6%B0%E1%BB%9Bng-d%E1%BA%ABn-g%C6%B0%CC%89i-y%C3%AAu-c%E1%BA%A7u-Tr%E1%BA%A3-h%C3%A0ng%2F-Ho%C3%A0n-ti%E1%BB%81n?previousPage=secondary%20category"
retrieved_at: "2026-09-20"
document_version: "not-stated"
---

# [Trả hàng/ Hoàn tiền] Hướng dẫn gửi yêu cầu Trả hàng/ Hoàn tiền | Shopee Trung tâm trợ giúp

[Trả hàng/ Hoàn tiền] Hướng dẫn gửi yêu cầu Trả hàng/ Hoàn tiền | Shopee Trung tâm trợ giúp

Xin chào, Shopee có thể giúp gì cho bạn?

[Trả hàng/ Hoàn tiền] Hướng dẫn gửi yêu cầu Trả hàng/ Hoàn tiền

1. Hướng dẫn gửi yêu cầu Trả hàng/Hoàn tiền

Khi cần yêu cầu trả hàng hoặc hoàn tiền trên Shopee, bạn có thể thực hiện theo một trong hai cách sau.

 

Cách 1: Gửi yêu cầu trực tiếp tại trang đơn hàng

Bước 1: Mở ứng dụng Shopee, vào mục Tôi > chọn thẻ Chờ giao hàng/Đã giao 

Bước 2: Tại đơn hàng bạn cần xử lý, bấm Trả hàng/Hoàn tiền.

Bước 3: Chọn tình huống bạn đang gặp

 

"Tôi đã nhận hàng nhưng hàng có vấn đề (bể vỡ, sai mẫu, hàng lỗi, khác mô tả,...) - Miễn ship hoàn về ": Dành cho trường hợp sản phẩm bị lỗi, thiếu, hoặc không đúng mô tả.

"Tôi chưa nhận hàng/nhận thiếu hàng": Dành cho trường hợp bạn chưa nhận được hàng hoặc bị thiếu sản phẩm trong đơn.

Bước 4: Chọn sản phẩm cần khiếu nại (trong trường hợp đơn hàng chỉ có 1 sản phẩm, bạn không cần chọn ở bước này)

Bước 5: Chọn lý do khiếu nại

Bước 6: Chọn phương án trả hàng/ hoàn tiền (nếu bạn chọn lý do khiếu nại Thiếu hàng)

Bước 7: Điền các thông tin cần thiết vào biểu mẫu, bao gồm:

Chú thích thêm tình trạng hàng hóa tại mục Mô tả.

Bằng chứng thể hiện tình trạng sản phẩm (hình ảnh sản phẩm, video mở hộp,...)

Email liên hệ.

Bước 8: Chọn Gửi yêu cầu để hoàn tất

 

3caad65c7fb64bfb884d71933efc0dad.mov

 

Cách 2: Gửi yêu cầu tại mục Trò Chuyện Với Shopee

Bước 1: Tại trang chủ Shopee, vào mục Tôi > chọn Trò Chuyện Với Shopee.

Bước 2: Chọn Khiếu nại trả hàng hoàn tiền.

Bước 3: Chọn đơn hàng bạn cần gửi yêu cầu.

Bước 4: Xác nhận và gửi yêu cầu

Xác nhận bạn Đã nhận hoặc Chưa nhận hàng.

Chọn lý do gửi yêu cầu.

Tải lên bằng chứng (ảnh/video).

Nhấn Gửi yêu cầu.

2. Lưu ý

Thời gian xử lý

Yêu cầu của bạn thường được xử lý trong khoảng 3 - 5 ngày làm việc.

Kết quả xử lý

Shopee sẽ thông báo kết quả qua mục Thông báo > Cập nhật đơn hàng và/hoặc Email của bạn.

Thời gian hoàn tiền

Nếu yêu cầu được chấp nhận, tiền sẽ được hoàn trong 1 - 14 ngày làm việc, tùy thuộc vào phương thức thanh toán. Để tìm hiểu thêm về thời gian hoàn tiền theo từng phương thức, vui lòng truy cập [Trả hàng/Hoàn tiền] Thời gian nhận tiền hoàn và cách kiểm tra tiền hoàn

Trường hợp Trả lại & Hoàn tiền

Bạn cần trả lại sản phẩm bằng cách yêu cầu bưu tá đến lấy hoặc tự ra bưu cục gửi. Sản phẩm sẽ được Người bán/Shopee xem xét khi nhận lại.

Bạn có hài lòng với bài viết này?

Hài lòng

Không hài lòng
